from bs4 import BeautifulSoup as bs
import requests
import time

import os

start = time.time()

response = requests.get("https://www.fnde.gov.br/siope/recibosTransmissao.do?tipoDeRecibo=1&cod_uf=42")

# Parse the HTML content
soup = bs(response.content, 'html.parser')

# Find all option elements within the select tag
options = soup.select('select[name="cod_uf"] option')

stateValues = dict()

# Extract and print the value and text of each option
for option in options:
    value = option['value']
    text = option.get_text(strip=True)
    stateValues[text] = value

for estado in os.listdir("./Estados"):
    cityWithStatus = dict()

    with open(f"./Estados/{estado}", "r", encoding="UTF-8") as f:
        lines = [x.replace("\n", "") for x in f.readlines()]
        if(lines == []):
            print(f"Estado {estado} sem municipios")
            continue

        state = estado
        stateValue = stateValues[state]
        url = f"https://www.fnde.gov.br/siope/recibosTransmissao.do?tipoDeRecibo=1&cod_uf=42&cod_uf_mun={stateValue}"

        response = requests.get(url)

        # Parse the HTML content
        soup = bs(response.content, 'html.parser')

        # Find all option elements within the select tag
        cities = soup.select('select[name="municipios"] option')
        citiesValues = dict()
        for city in cities:
            value = city['value']
            text = city.get_text(strip=True)
            citiesValues[text] = value
        
        for city in lines:
            value = citiesValues[city]
            url = f"https://www.fnde.gov.br/siope/recibosTransmissao.do?tipoDeRecibo=1&cod_uf=42&cod_uf_mun={stateValue}&municipios={value}&consultar=Consultar"
            response = requests.get(url)

            # Parse the HTML content
            soup = bs(response.content, 'html.parser')
            # Find all <tr> elements with class "rowA"
            tr_elements = soup.find_all('tr', class_='rowA')

            # Get the first occurrence (if any)
            first_occurrence = tr_elements[0] if tr_elements else None
            if(first_occurrence is None):
                print("Não achei carai nenhum")
                continue

            td_elements = first_occurrence.find_all('td')
            cityWithStatus[city] = td_elements[0].get_text(strip=True)

            print(f"{state} - {city} - COMPLETED")
        
        with open(f"{state}.csv", "w", encoding="UTF-8") as ff:
            ff.write("Cidade,Homologado\n")
            for city in cityWithStatus.keys():
                status = cityWithStatus[city]
                ff.write(f"{city},{status}\n")

    end = time.time()
    length = end - start
    # Show the results : this can be altered however you like
    print("It took", length, "seconds!")